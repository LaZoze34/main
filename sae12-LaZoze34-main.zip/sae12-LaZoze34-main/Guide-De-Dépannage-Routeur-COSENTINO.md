<font size="2.5">**COSENTINO Enzo RT1-B1**</font>
<br>
<br>
<br>
<br>
<h1><center><font size="6"> Guide de dépannage d'un routeur 
</font></center></h1>   
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
Pour prendre un exemple de dépannage de routeur, voici mon schéma fait durant cette SAE : 
<br>
<br>
<br>

![img](Montage_Routeur.png )

<br>
<br>
<br>
<br>

Pour commencer la manipulation, on va d'abord regarder au niveau de notre terminal pour vérifier si le routeur peut adresser tout seul les @IP ou bien si c'est à nous de faire l'adressage. 
<br>
<br><br>
<br>
Dans cet exemple, on va procéder à l'adressage : 
<br>
<br>
<br>
<br>
En premier temps, nous allons ajouter un adresse IP à notre PC car il en a pas
<br>
<br>
<br>
<br>
Grâce à la commande : 
<br>
<br>

       sudo ip addr add "votre_adresse" dev "votre_interface"

Et grâce à la commande "ip a", on peut voir que notre adresse s'est bien affectée à notre PC : 
<br>
<br>

![images](Guide%20Routage/ipa.png)
<br>
<br>

Ensuite, il nous faut adresser une route par defaut : 

        sudo ip route add default via "votre_passerelle" dev "votre_interface"

<br>
<br>

Et grâce à la commande "ip route", on peut voir que notre gateway s'est bien affectée à notre PC :
<br>
<br>

![images](Guide%20Routage/ip%20r.png)

<br>
<br>

Une fois que on a réussi à adresser notre PC, on va passer à la configuration de notre routeur : 
<br>
<br>

![images](Guide%20Routage/Adressage.png)
<br>
<br>
On met notre adressage en statique et on peut faire les modifications dans notre adressage si on le souhaite. 

<br>
<br>

Pour pouvoir communiquer avec d'autres routeurs externes, on peut le faire si on ajoute les routes "gateway" des autres routeurs : 
<br>
<br>

![images](Guide%20Routage/Ajouter%20une%20route.png)
<br>
<br>
Dans l'exemple, j'utilise la commande : 
<br>
<br>
            
    ip route add dst-address="adresse_d'un_routeur_externe" gateway="adresse_que_l_hote_à_configurer"

<br>
<br>
Pour vérifier que les routes ont étaient affectées, je regarde la configuration des routes dans l'onglet dédié : 
<br>
<br>

![images](Guide%20Routage/tablederoutage.png)
<br>
<br>

Une fois toutes ces manipulations faites, on va tester pour voir si celà fonctionne :
<br>
<br>

![img](Guide%20Routage/ping.png)
<br>
<br>
On peut donc voir que je peux communiquer avec un routeur externe depuis mon réseau ! 👍
<br>
<br>

Deuxième test avec Google :
<br>
<br>

![img](Guide%20Routage/ping2.png)
<br>
<br>
👍👍👍👍👍👍👍👍
<br>
<br>
Traceroute : 
<br>
<br>

![img](Guide%20Routage/Traceroute.png)
<br>
<br>

Pour conclure, on peut voir que mon routeur avec la configuration faite peut communiquer avec un routeur extérieur de mon réseau. On peut donc voir que la compétence est validée 😄