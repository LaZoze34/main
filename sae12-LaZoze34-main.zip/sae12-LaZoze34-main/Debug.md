**COSENTINO Enzo RT1-B1**


<h1><center><font size="6"> Guide de dépannage réseaux sous Linux / sous Windows 
</font></center></h1>   
<br>
<br>
<br>
<br>
<font size="3">Tout d'abord, on va faire un point sur ce qui entoure les problèmes que l'ont peut rencontré sur notre réseau. Pour commencer, le réseau de quoi est-il composé ?</font>
<br> 
<br>
<br>

<font size="5">1. **DNS**</font>
<br>
<br>


<img src="https://special-it.fr/wp-content/uploads/2019/08/DNS.png"/>

<br>
Le service DNS (Domain Name Service) est un service qui permet d’associer un nom compréhensible, à une adresse IP. On associe donc une adresse logique, le nom de domaine, à une adresse physique l’adresse IP.
Le serveur DNS agit comme un annuaire que consulte un ordinateur au moment d'accéder à un autre ordinateur via un réseau. 

<br>
<br>

<font size="5">2.  **Le routeur**</font>

<br>
<br>
<br>
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRuU9xSHVZ8knErJNC0rrrv_WtP4pshSOuRKQ&usqp=CAU"/>
<br>
<br>
<br>
<br>

 Le **routeur** est un élément important d'un réseau, c'est celui qui permet de nous connecter au monde extérieur. 

 Un routeur est un appareil capable de gérer un petit réseau (par exemple le réseau de votre domicile) et de distribuer une connexion Internet à tous les ordinateurs de votre réseau domestique, soit par câble, soit sans-fil. 
 Les "Box" comme la Freebox ou la Livebox intègrent déjà un routeur.

 La plupart des fournisseurs d’accès à Internet vous fourniront une Box Internet, un boitier qui a le rôle de routeur, modem et pare-feu en même temps. Il faudra le brancher un filtre ADSL bien souvent puis sur la prise téléphonique. Le routeur est capable de distribuer la connexion via un réseau câblé RJ45, ou sans fil avec le Wi-Fi.


<br>
<br>
<br>

<font size="5">3. **L'adresse IP**</font>
<br>
<br>

Qu'est ce que'une adresse IP ? 

<br>
L'adresse IP (Internet Protocol) désigne un numéro unique attribué de manière provisoire ou durable à un ordinateur connecté à un réseau informatique qui utilise l'internet protocole.

<br>
<br>

Dans un second temps, on va voir comment faire un dépannage sous Linux et Windows, et voir les premières méthodes à utiliser pour pouvoir détecter potentiellement une panne sans forcémment faire appel à un professionnel et débourser un somme astronomique dans celà. 

<br>
<br>
<br>


<font size="5"> 4. **Sous Linux** </font>
<br>
<br>
<br>

Qu'est ce que Linux ? Car tout le monde est peut-être susceptible de ne pas connaître ce fameux Linux ! 

<br>

Donc Linux est une famille de systèmes d'exploitation open source de type Unix fondé sur le noyau Linux, créé en 1991 par Linus Torvalds. De nombreuses distributions Linux ont depuis vu le jour et constituent un important vecteur de popularisation du mouvement du logiciel libre. Les versions les plus connues sont Ubuntu et Debian par exemple. 

<br>

|<center>Commande</center>                 |        <center>Explications</center>                     |                         |
|----------------|-------------------------------|-----------------------------|
| <center>ip addr show / if config |<center>Permet de vérifier l'interface           |          |
| <center> ping www.test.tf / ping6 www.test.tf  | <center>Test de connectivité IPv4 / IPv6
|<center>ip route           |<center>Vérification de la table de routage (IPv4/IPv6)           |
|<center>traceroute 176.31.61.170          |<center>Vérification des sauts||
|<center>cat /etc/resolv.conf       |  <center>Serveur de nom                  | <center>                            |
|<center>nslookup / dig| <center>Requête DNS | |
|<center>/etc/network/interfaces | <center>Pour Débian pour les fichiers de configuration des interfaces      

<br>
<br>

<font size="5"> 5. **Sous Windows** </font>

<br>
<br>
Qu'est ce que Windows ? 
<br>
<br>
Microsoft Windows est un système d’exploitation, c’est-à-dire, un ensemble de programmes (dits logiciels) permettant de gérer les ressources d’un ordinateur. Ce genre de systèmes se met en marche à partir du moment où on allume l’équipement pour gérer le matériel informatique à partir des niveaux les plus basiques.

Il y a lieu de mentionner que les systèmes d’exploitation marchent aussi bien sur les ordinateurs que sur d’autres dispositifs électroniques faisant appel à des microprocesseurs (téléphones portables, lecteurs de DVD, etc.). Dans le cas de Windows, sa version standard fonctionne sur des ordinateurs, bien qu’il existe aussi une version pour les portables (Windows Mobile).

<br>

|<center>Commande</center>                 |        <center>Explications</center>                     |                         |
|----------------|-------------------------------|-----------------------------|
| <center>ipconfig / netsh interface ipv4 show add / netsh interface ipv6 show add |<center>Permet de vérifier l'interface           |          |
| <center> ping www.test.tf  | <center>Test de connectivité IPv4 sans connectivité IPv6
|<center>    ipconfig / route/ netsh interface ipv4 show route / netsh interface ipv6 show route           |<center>Vérification de la table de routage (IPv4/IPv6)           |
|<center>tracert 176.31.61.170         |<center>Vérification des sauts||
|<center>    ifconfig /all / netsh interface ipv4 show config / netsh interface ipv6 show config       |  <center>Serveur de nom                  | <center>                            |
|<center>nslookup | <center>Requête DNS |
---