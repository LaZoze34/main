<font size="2.5">**COSENTINO Enzo RT1-B1**</font>
<br>
<br>
<br>
<br>
<h1><center><font size="6"> Guide d'installation d'une VM (avec VirtualBox)
</font></center></h1>   
<br>
<br>
<br>
<br>
<br>
Tout d'abord, qu'est ce qu'une VM ? 
<br>
<br>

Donc une VM est une **machine virtuelle** ou « virtual machine », est « le client » créé dans un environnement informatique, « l'hôte ». Plusieurs machines virtuelles peuvent coexister sur un seul hôte.
<br>
<br>
Il faut savoir que on peut créer des VM avec des logiciels comme VirtualBox gratuitement à l'aide d'une image ISO. 
<br>
<br>
Qu'est ce qu'une image ISO ? 
<br>
<br>

Un **fichier ISO**, pour "International Organization for Standardization", est un fichiers **image** d'un disque optique (CD, DVD, blu-ray, etc.). Il reprend l'ensemble des secteurs de données présents sur le disque, son contenu est strictement identique à celui présent sur le disque (dossiers, fichiers, arborescence).
<br>
<br>

Pour commencer, on va passer par l'installation de VirtualBox disponbile sur son site https://www.virtualbox.org/wiki/Downloads gratuitement.
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/5fe537584f6647bfcf1d6c72b928d32fa63f5558/GuideVM/Virtualbox%20download.PNG">

<br>
<br>
Une fois le logiciel téléchargé, on l'ouvre pour commencer l'installation : 
<br>
<br>

On clique sur nouvelle 

![images](/GuideVM/Créer%20VM.PNG)
<br>
<br>

Ensuite, on nomme notre VM au nom que l'on souhaite et on choisit sur quel licence on veut faire marcher notre VM (sur cet exemple on fait tourner sous Ubuntu)

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/2.PNG">
<br>
<br>

Ensuite, On définit la mémoire que l'on souhaite lui attitré à cette VM : 
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/3.PNG">

<br>
<br>

Ensuite c'est à vous de choisir si vous voulez créer un disque dur virtuel ou alors utiliser votre disque dur (dans l'exemple, on va créer un disque virtuel.)
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/4..PNG">

<br>
<br>

Ensuite, le logiciel vous demande quel type de fichier de disque dur on désire utiliser donc je choisis dans mon cas VDI car je vais télécharger une image ISO sur internet. 
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/5.PNG">

<br>
<br>
On choisi de le dynamiquement alloué 
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/6.PNG">

<br>
<br>
On choisi la taille de disque dur que l'on souhaite : 
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/7.PNG">


<br>
<br>
Voilà nous avons réussi à créer une partie de notre VM manque plus qu'à la configurer 👍
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/8.PNG">

<br>
<br>
On va dans configuration -> Stockage pour ajouter la clé ISO précédemment télécharger.
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/9.PNG">

<br>
<br>

On ajoute la clé iso qui est dans un dossier de notre choix. 

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/10.PNG">

<br>
<br>
On peut voir que la clé iso s'est bien appliquée.
<br>
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/11.PNG">

<br>
<br>
<br>
<br>

Une fois cette manipulation faite, on démarre à la VM pour commencer l'installation 👍
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/12.PNG">

<br>
<br>
On choisi la langue et on clique sur installer Ubuntu ! 
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/13.PNG">

<br>
<br>

Sélectionner la disposition du clavier de votre choix ! 
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/14.PNG">

<br>
<br>


Ici on va choisir un installation normale !
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/15.PNG">

<br>
<br>
On choisi d'effacer les fichiers ubuntu comme ça il y aura aucune erreur ! 
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/16.PNG">

<br>
<br>

Continuez ! 
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/17.PNG">

<br>
<br>
Choisissez un nom et un nom d'utilisateur de votre choix pour ma part c'est test et mot de passe test.
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/18.PNG">

<br>
<br>

On peut voir que l'installation commence. 
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/19.PNG">

<br>
<br>



<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/20.PNG">

<br>
<br>

Une fois l'installation finie, redémarrer la machine pour appliquer l'installation.
<br>
<br>
<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/21.PNG">

<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/22.PNG">

<br>
<br>
Et voilà, vous avez réussi à installer votre VM Ubuntu sans problème et elle est clean en plus ! 👍
<br>
<br>

<img src="https://github.com/IUT-Beziers/sae12-LaZoze34/blob/04bdea745e62ed9bc362c5693e0598eef43f1803/GuideVM/23.PNG">

<br>
<br>
